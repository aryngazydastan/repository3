module PharmaciesHelper
end
