require 'test_helper'

class PharmaciesHelperTest < ActionView::TestCase
end
